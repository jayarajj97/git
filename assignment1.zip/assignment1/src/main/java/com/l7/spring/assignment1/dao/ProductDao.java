package com.l7.spring.assignment1.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.l7.spring.assignment1.dto.Product;
@Component
public interface ProductDao {

	List<Product> getAllproducts();

	Product addProduct(Product product);

	void deleteProductById(int id);

	Product getProductById(int productId);

}
