package com.l7.spring.assignment1.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.l7.spring.assignment1.dto.Product;
@Component
public interface ProductService {

	List<Product> getAllProducts();

	Product addProduct(Product product);

	void deleteProductById(int id);

	Product getProductbyId(int productId);

}
