package com.l7.spring.assignment1.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.l7.spring.assignment1.dao.ProductDao;
import com.l7.spring.assignment1.dto.Product;
import com.l7.spring.assignment1.service.ProductService;
@Component
@Primary
public class DefaultProductService implements ProductService{
	@Autowired
	ProductDao productDao;
	@Override
	public List<Product> getAllProducts() {
		
		return productDao.getAllproducts();
	}
	@Override
	public Product addProduct(Product product) {
		return productDao.addProduct(product);
	}
	@Override
	public void deleteProductById(int id) {
		productDao.deleteProductById(id);
	}
	@Override
	public Product getProductbyId(int productId) {
		return productDao.getProductById(productId);
	}

}
