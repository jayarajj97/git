package com.l7.spring.assignment1.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.l7.spring.assignment1.dto.Product;
import com.l7.spring.assignment1.service.ProductService;

@RestController
@Component
public class ProductController {
	@Autowired
	private ProductService productService;

	@GetMapping("/products")
	public List<Product> getAllProducts() {
		List<Product> products = productService.getAllProducts();
		if(products==null) {
			throw new ProductNotFoundException("products-"+products);
		}
		return products;
	}

	@GetMapping("/products/{productId}")
	public Product getProductbyId(@PathVariable int productId) {
		Product product=productService.getProductbyId(productId);
		if(product==null) {
			throw new ProductNotFoundException("productId-"+productId);
		}
		
		return product;

	}

	@PostMapping("/products")
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {

		Product savedProduct = productService.addProduct(product);

		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("{productId}")
				.buildAndExpand(savedProduct.getProductId()).toUri();
		return ResponseEntity.created(location).build();
	}

	@DeleteMapping("/products/{id}")
	public void deleteProductById(@PathVariable int id) {

		productService.deleteProductById(id);
	}

}
