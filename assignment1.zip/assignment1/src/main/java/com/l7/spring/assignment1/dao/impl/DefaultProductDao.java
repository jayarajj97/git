package com.l7.spring.assignment1.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.l7.spring.assignment1.dao.ProductDao;
import com.l7.spring.assignment1.dto.Product;

@Component
@Primary
public class DefaultProductDao implements ProductDao {

	private static List<Product> products;

	DefaultProductDao() {
		List<Product> dummyProducts = new ArrayList<>();
		dummyProducts.add(new Product(dummyProducts.size() + 1, "Product_1"));
		dummyProducts.add(new Product(dummyProducts.size() + 1, "Product_2"));
		dummyProducts.add(new Product(dummyProducts.size() + 1, "Product_3"));
		dummyProducts.add(new Product(dummyProducts.size() + 1, "Product_4"));
		dummyProducts.add(new Product(dummyProducts.size() + 1, "Product_5"));
		dummyProducts.add(new Product(dummyProducts.size() + 1, "Product_6"));
		DefaultProductDao.products = dummyProducts;
	}

	@Override
	public List<Product> getAllproducts() {
		return products;
	}

	@Override
	public Product addProduct(Product product) {
		if (product.getProductId() == 0) {
			product.setProductId(products.size() + 1);
		}
		products.add(product);
		return product;
	}

	@Override
	public void deleteProductById(int id) {
		products.removeIf(product -> (product.getProductId() == id));
	}

	@Override
	public Product getProductById(int productId) {
		List<Product> selectedProducts = products.stream().filter(product -> product.getProductId() == productId).collect(Collectors.toList());
		return selectedProducts.size()==0?null:selectedProducts.get(0);
	}

}
